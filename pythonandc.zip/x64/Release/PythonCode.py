import re
import string


def printsomething():
    f = open("frequency.dat", "r")
    data = f.read()
    print(data)

def printNumTimes():
    f = open("frequency.dat", "r")
    data = f.read()
    temp = ""
    dataList = []
    for i in data:
        if i != '\n':
            temp += i
        else:
            dataList.append(temp)
            temp = ""
    dataList.append(temp)
    newList = []
    newList.append(dataList[0])
    addTo = True
    for i in dataList:
        addTo = True
        for j in newList:
            if i == j:
                addTo = False
        if addTo == True:
            newList.append(i)
    numList = []
    k = 0
    while k < len(newList):
        numList.append(0)
        k += 1
    k = 0
    for i in newList:
        for j in dataList:
            if i == j:
                numList[k] += 1
        k += 1
    k = 0
    while k < len(newList):
        print(newList[k], " ", numList[k])
        k += 1
    f.close()

def searchWord(foo):
    f = open("frequency.dat", "r")
    data = f.read()
    temp = ""
    dataList = []
    for i in data:
        if i != '\n':
            temp += i
        else:
            dataList.append(temp)
            temp = ""
    dataList.append(temp)
    newList = []
    newList.append(dataList[0])
    addTo = True
    for i in dataList:
        addTo = True
        for j in newList:
            if i == j:
                addTo = False
        if addTo == True:
            newList.append(i)
    numList = []
    k = 0
    while k < len(newList):
        numList.append(0)
        k += 1
    k = 0
    for i in newList:
        for j in dataList:
            if i == j:
                numList[k] += 1
        k += 1
    k = 0
    for i in newList:
        if foo == i:
            print(i, " ", numList[k])
        k += 1
    f.close()
    return 0

def printHistogram():
    f = open("frequency.dat", "r")
    data = f.read()
    temp = ""
    dataList = []
    for i in data:
        if i != '\n':
            temp += i
        else:
            dataList.append(temp)
            temp = ""
    dataList.append(temp)
    newList = []
    newList.append(dataList[0])
    addTo = True
    for i in dataList:
        addTo = True
        for j in newList:
            if i == j:
                addTo = False
        if addTo == True:
            newList.append(i)
    numList = []
    k = 0
    while k < len(newList):
        numList.append(0)
        k += 1
    k = 0
    for i in newList:
        for j in dataList:
            if i == j:
                numList[k] += 1
        k += 1
    k = 0
    m = 0
    temp2 = ""
    while k < len(newList):
        m = 0
        while m < numList[k]:
            temp2 += '*'
            m += 1
        print(newList[k], " ", temp2)
        temp2 = ""
        k += 1
    f.close()

def PrintMe(v):
    print("You sent me: " + v)
    return 100;

def SquareValue(v):
    return v * v



    
