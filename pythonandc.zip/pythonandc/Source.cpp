#include <Python.h>
#include <iostream>
#include <Windows.h>
#include <cmath>
#include <string>

using namespace std;

/*
Description:
	To call this function, simply pass the function name in Python that you wish to call.
Example:
	callProcedure("printsomething");
Output:
	Python will print on the screen: Hello from python!
Return:
	None
*/
void CallProcedure(string pName)
{
	char* procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyObject* my_module = PyImport_ImportModule("PythonCode");
	PyErr_Print();
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("PrintMe","Test");
Output:
	Python will print on the screen:
		You sent me: Test
Return:
	100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	char* paramval = new char[param.length() + 1];
	std::strcpy(paramval, param.c_str());


	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(z)", paramval);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;
	delete[] paramval;


	return _PyLong_AsInt(presult);
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("doublevalue",5);
Return:
	25 is returned to the C++
*/
int callIntFunc(string proc, int param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(i)", param);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;

	return _PyLong_AsInt(presult);
}


void main()
{
	string choice = "";
	string foo = "";
	while (true) {/// while loop on interface
		cout << "Please Choose an action:" << endl;
		cout << "1. Output list with frequency" << endl;
		cout << "2. Search for Item and display frequency" << endl;
		cout << "3. Output Histogram" << endl;
		cout << "4. Exit Program ----" << endl;
	    choice = "";
		try {// input validation
			cin >> choice;
			if (cin.fail()) {
				throw 0;
			}
		}
		catch (int err) {
			cin.clear();/// you have to clear cin when input is invalid
			cin.ignore('\n', 256);
			choice = "ERRORNEVERUSE";
		}/// end input validation
		if (choice != "ERRORNEVERUSE") {
			if (choice == "1") {
				CallProcedure("printNumTimes");///everything important is happening in python
			}
			else if (choice == "2") {
				try {//input validation
					cin >> foo;
					if (cin.fail()) {
						throw 0;
					}
				}
				catch (int err) {
					cin.clear();//clears cin
					cin.ignore('\n', 256);
					foo = "ERRORNEVERUSE";
				}// end inputvalidation
				if (foo == "ERRORNEVERUSE") {
					cout << "INVALID INPUT!!!!!!!" << endl;
				}
				else {
					callIntFunc("searchWord", foo);
				}
				foo = "";///reset foo
			}
			else if (choice == "3") {
				CallProcedure("printHistogram");
			}
			else if (choice == "4") {///Exit Program
				return;
			}
			else {
				cout << "INVALID INPUT" << endl;
			}
		}
		else {
			cout << "ERROR-INVALID INPUT" << endl;//errormessage
		}
	}

	///CallProcedure("searchWord");
	///cout << callIntFunc("PrintMe", "House") << endl;
	///cout << callIntFunc("SquareValue", 2);

}